package com.kingstar.gamer

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val channelUrl = "https://youtube.com/@kingstargamer2.0"
    private val gold = Color.parseColor("#FFC107")
    private val bg = Color.parseColor("#0D0D12")
    private var waitingForPermission = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        root.addView(spacer(1f))

        root.addView(TextView(this).apply {
            text = "★"
            textSize = 64f
            setTextColor(gold)
            gravity = Gravity.CENTER
        })

        root.addView(TextView(this).apply {
            text = "King Star Gamer 2.0"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(24))
        })

        root.addView(Button(this).apply {
            text = "START ON"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(bg)
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(gold)
            }
            setOnClickListener { onStartPressed() }
        }, LinearLayout.LayoutParams(dp(240), dp(56)))

        root.addView(Button(this).apply {
            text = "YouTube Channel"
            textSize = 14f
            setTextColor(gold)
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), gold)
            }
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl)))
            }
        }, LinearLayout.LayoutParams(dp(240), dp(48)).apply { topMargin = dp(16) })

        root.addView(spacer(1f))

        root.addView(TextView(this).apply {
            text = "Created by King Star Gamer 2.0"
            textSize = 13f
            setTextColor(Color.parseColor("#9A9AA5"))
            gravity = Gravity.CENTER
        })

        setContentView(root)
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, 0, weight)
    }

    private fun onStartPressed() {
        if (Settings.canDrawOverlays(this)) {
            startFloating()
        } else {
            waitingForPermission = true
            Toast.makeText(this, "Allow \"Display over other apps\" for King Star", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }

    override fun onResume() {
        super.onResume()
        if (waitingForPermission && Settings.canDrawOverlays(this)) {
            waitingForPermission = false
            startFloating()
        }
    }

    private fun startFloating() {
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "King Star started", Toast.LENGTH_SHORT).show()
        finish()
    }
}
