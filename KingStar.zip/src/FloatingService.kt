package com.kingstar.gamer

import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {

    private class AppItem(val label: String, val info: ResolveInfo)

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelShown = false
    private var apps: List<AppItem> = emptyList()

    private val gold = Color.parseColor("#FFC107")
    private val dark = Color.parseColor("#0D0D12")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        loadApps()
        addBubble()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("kingstar", "King Star", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", stopIntent
        ).build()
        val n = Notification.Builder(this, "kingstar")
            .setContentTitle("King Star Gamer 2.0")
            .setContentText("Floating launcher is running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(stopAction)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it) }
            .sortedBy { it.label.lowercase() }
    }

    private fun addBubble() {
        val size = dp(56)
        val tv = TextView(this).apply {
            text = "★"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(dark)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(gold)
                setStroke(dp(2), Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun togglePanel() {
        if (panelShown) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panel == null) panel = buildPanel()
        val dm = resources.displayMetrics
        val w = minOf(dm.widthPixels - dp(24), dp(360))
        val h = (dm.heightPixels * 0.55).toInt()
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        try {
            wm.addView(panel, lp)
            panelShown = true
        } catch (_: Exception) {
        }
    }

    private fun hidePanel() {
        if (panelShown) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panelShown = false
        }
    }

    private fun buildPanel(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#16161F"))
                setStroke(dp(2), gold)
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "King Star Gamer 2.0"
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(gold)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "✕"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { hidePanel() }
        })
        box.addView(header)

        val grid = GridView(this).apply {
            numColumns = 4
            verticalSpacing = dp(12)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(0, dp(10), 0, 0)
            adapter = object : BaseAdapter() {
                override fun getCount() = apps.size
                override fun getItem(position: Int): Any = apps[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val item = apps[position]
                    val cell = LinearLayout(this@FloatingService).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER_HORIZONTAL
                    }
                    cell.addView(ImageView(this@FloatingService).apply {
                        setImageDrawable(item.info.loadIcon(packageManager))
                    }, LinearLayout.LayoutParams(dp(46), dp(46)))
                    cell.addView(TextView(this@FloatingService).apply {
                        text = item.label
                        textSize = 11f
                        maxLines = 1
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        gravity = Gravity.CENTER
                        setTextColor(Color.WHITE)
                    })
                    return cell
                }
            }
            onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
                launchApp(apps[pos])
            }
        }
        box.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return box
    }

    private fun launchApp(item: AppItem) {
        val ai = item.info.activityInfo
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(ai.packageName, ai.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.62).toInt()
        val h = (dm.heightPixels * 0.42).toInt()
        val right = dm.widthPixels - dp(8)
        val top = dp(90)
        val options = ActivityOptions.makeBasic().setLaunchBounds(Rect(right - w, top, right, top + h))

        hidePanel()
        try {
            startActivity(intent, options.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open ${item.label}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        hidePanel()
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        super.onDestroy()
    }
}
